package database;

import java.sql.*;

/**
 * 类说明
 * 1.连接数据库
 * 2.实现对UserIP的增加,清空,查询特定IP操作
 * 3.实现对BlockNumber表的更新，置零操作
 */
public class crud {
    private final String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    private final String dbURL = "jdbc:sqlserver://localhost:1433;databaseName=Users";
    private final String userName = "sa";
    private final String userPwd = "991018";

    /**
     * 连接数据库（Users）
     * 采用SQL Server
     *
     * @param driverName 驱动名
     * @param dbURL      数据库地址
     * @param userName   用户名
     * @param userPwd    密码
     * @return 返回一个数据库的连接？
     */
    public static Connection Connect(String driverName, String dbURL, String userName, String userPwd) {
        Connection connection = null;
        try {
            Class.forName(driverName);
            connection = DriverManager.getConnection(dbURL, userName, userPwd);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    /**
     * 向数据库中增加用户IP数据
     *
     * @param IP 要增加的用户IP地址
     * @throws SQLException
     */
    public void addUser(String IP) throws SQLException {
        Connection connection = Connect(driverName, dbURL, userName, userPwd);
        String insertSQL = "insert into UserIP values(?);";
        PreparedStatement pst = connection.prepareStatement(insertSQL);
        pst.setString(1, IP);
        try {
            pst.executeUpdate();//执行插入操作
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                connection.close();//插入完成后关闭数据库
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 使某图块对应的用户数自增1
     *
     * @param BlockLocation 你所选择的图块（按拨号盘顺序1~9）
     * @throws SQLException
     */
    public void updateNumber(int BlockLocation) throws SQLException {
        Connection connection = Connect(driverName, dbURL, userName, userPwd);
        String updateSQL = "update Block set UsersNumber=UsersNumber+1 where BlockLocation = '" + BlockLocation + "'";
        PreparedStatement pst = connection.prepareStatement(updateSQL);
        try {
            pst.executeUpdate();//执行更新操作
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                connection.close();//更新完成后关闭数据库
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 查询数据库中指定IP
     *
     * @param selectedIP 要查询的IP地址
     * @return 如果存在该IP则返回true，否则返回false
     * @throws SQLException
     */
    public Boolean selectUser(String selectedIP) throws SQLException {
        Connection connection = Connect(driverName, dbURL, userName, userPwd);
        Statement statement = connection.createStatement();
        String selectSQL = "select * from UserIP where IPAddress = '" + selectedIP + "'";
        ResultSet rs = statement.executeQuery(selectSQL);
        return rs.next();
    }

    /**
     * 删除数据库中全部IP数据
     *
     * @throws SQLException
     */
    public void deleteUsers() throws SQLException {
        Connection connection = Connect(driverName, dbURL, userName, userPwd);
        String deleteSQL = "truncate table UserIP";//不但将数据全部删除，而且重新定位自增的字段
        PreparedStatement pst = connection.prepareStatement(deleteSQL);
        try {
            pst.executeUpdate();//执行删除操作
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                connection.close();//删除完成后关闭数据库
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 将全部图块对应用户数清零
     *
     * @throws SQLException
     */
    public void clearNumber() throws SQLException {
        Connection connection = Connect(driverName, dbURL, userName, userPwd);
        String updateSQL = "update Block set UsersNumber=0";//将每个图块对应的用户数清零
        PreparedStatement pst = connection.prepareStatement(updateSQL);
        try {
            pst.executeUpdate();//执行更新操作
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                connection.close();//更新完成后关闭数据库
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 返回某个块的统计数据
     *
     * @param BlockLocation 想获得统计值的图块（1~9）
     * @return 选择当前块的人数
     * @throws SQLException
     */
    public int selectNumber(int BlockLocation) throws SQLException {
        Connection connection = Connect(driverName, dbURL, userName, userPwd);
        Statement statement = connection.createStatement();
        String selectSQL = "select UsersNumber from Block where BlockLocation = '" + BlockLocation + "'";
        ResultSet rs = statement.executeQuery(selectSQL);
        rs.next();
        return rs.getInt("UsersNumber");
    }

    /**
     * 从颜色表中选择一种颜色
     *
     * @param color 要选择的颜色名
     *              <br>颜色从浅到深为：white、grey、green、brown、red
     * @return 返回对应颜色名的hex值，如white对应#FFFFFF
     * @throws SQLException
     */
    public String selectColor(String color) throws SQLException {
        Connection connection = Connect(driverName, dbURL, userName, userPwd);
        Statement statement = connection.createStatement();
        String selectSQL = "select ColorHEX from Color where ColorName = '" + color + "'";
        ResultSet rs = statement.executeQuery(selectSQL);
        rs.next();
        return rs.getString("ColorHEX");
    }

    /**
     * 读取Block表中每个块选择的用户数
     *
     * @return 返回数据的字符串数组
     * @throws SQLException
     */
    public int[] readAllNumbers() throws SQLException {
        Connection connection = Connect(driverName, dbURL, userName, userPwd);
        Statement statement = connection.createStatement();
        String selectSQL = "select UsersNumber from Block";
        ResultSet rs = statement.executeQuery(selectSQL);
        int[] numbers = new int[10];
        for (int i = 1; i <= 9 && rs.next(); i++) {
            numbers[i] = rs.getInt("UsersNumber");
        }
        return numbers;
    }

    /**
     * 读取数据库中当前时间的值
     *
     * @return 返回当前倒计时
     * @throws SQLException
     */
    public int readTime() throws SQLException {
        Connection connection = Connect(driverName, dbURL, userName, userPwd);
        Statement statement = connection.createStatement();
        String selectSQL = "select countDown from CountDown where symbol=1";
        ResultSet rs = statement.executeQuery(selectSQL);
        rs.next();
        return rs.getInt("countDown");
    }

    /**alert("游戏结束!")
     * 实现CountDown表中的数据自减
     *
     * @throws SQLException
     */
    public void countDown() throws SQLException {
        Connection connection = Connect(driverName, dbURL, userName, userPwd);
        String updateSQL = "update CountDown set countDown=countDown-0.25 where symbol=1";
        PreparedStatement pst = connection.prepareStatement(updateSQL);
        pst.executeUpdate();
    }

    /**
     * 重置时间表
     *
     * @throws SQLException
     */
    public void resetTime() throws SQLException {
        Connection connection = Connect(driverName, dbURL, userName, userPwd);
        String updateSQL = "update CountDown set countDown=60";
        PreparedStatement pst = connection.prepareStatement(updateSQL);
        pst.executeUpdate();
    }
}
