package service;

import database.crud;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 * 类说明：
 * 1.接收手机信息（IP地址）
 * 2.返回计数统计结果
 * 3.点亮预设可视化方式中与手机所发信息对应的拼图图块
 * <p>
 * 限定条件：
 * 1.一个手机只能发送一次数据
 * 2.多台手机位置信息相同时，对应图块颜色加深并显示数量
 * 3.对应图块未收到收集数据时为透明色或白色
 */
@WebServlet("/handle")
public class handle extends HttpServlet {
    @Override
    public void init() throws ServletException {
        System.out.println("Servlet被创建了……");
    }

    //获取客户端IP地址
    public String getRemoteIP(HttpServletRequest request) {
        if (request.getHeader("x-forwarded-for") == null) {
            return request.getRemoteAddr();
        }
        return request.getHeader("x-forwarded-for");
    }

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //收到某用户传递的ip地址和他选择的块号block
        String ipaddress = getRemoteIP(request);
        int block = Integer.parseInt(request.getParameter("block"));

        crud crud = new crud();
        service serv = new service();

        //验证“一台手机只能发送一次数据”，对新用户的相关数据做入库处理
        try {
            if (crud.selectUser(ipaddress)) {//同一用户重复发送数据
                System.out.println("重复用户发送数据，已忽略……");
            } else {//新用户,写入数据库
                //对UserIP表添加用户IP地址
                crud.addUser(ipaddress);
                //对Block表添加对应块上的用户数
                crud.updateNumber(block);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("验证同一用户出错……");
        }
        /**
         * 实现倒计时
         */
        try {
            crud.countDown();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        request.getRequestDispatcher("game.jsp").forward(request, response);
    }

    @Override
    public void destroy() {
        System.out.println("Servlet被销毁了……");
    }
}
