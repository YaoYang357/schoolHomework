package service;

import database.crud;

import java.sql.SQLException;

/**
 * 类方法说明
 * 1.用来给出限定时间
 * 2.给出完成的百分度
 * 3.点亮与所发信息对应的图块
 * <p>
 * 限定条件
 * 1.限定时间采用秒来表示
 * 2.百分度保留小数点后两位小数
 * 3.多台手机选择同一图块，该图块颜色加深，默认为白色
 * <p>
 * 实现思路
 * 1.用一个数组block[10]分别表示1~9个图块
 * 计算百分度就是计算数组中非零值个数占总数的百分比
 */
public class service {
    crud sql = new crud();//数据库对象，实现与数据库有关的操作

    /**
     * 给出拼图完成的百分度
     *
     * @param block 数组中内容为每个块对应的UsersNumber
     * @return 返回字符串类型的百分数，保留两位小数
     */
    public String degree(int[] block) {
        float notNull = 0;
        for (int i = 0; i < 10; i++)
            if (block[i] != 0) {
                notNull++;
            }
        return String.format("%.2f%%", (notNull / 9) * 100);
    }

    /**
     * 根据输入的位置信息，判断并返回对应的颜色值
     *
     * @param BlockLocation 图块的位置（1~9）
     * @return 返回此时该图块应对应的颜色的HEX值
     */
    public String setColor(int BlockLocation) throws SQLException {
        int Number = sql.selectNumber(BlockLocation);
        switch (Number) {
            case 1:
                return sql.selectColor("grey");
            case 2:
                return sql.selectColor("green");
            case 3:
                return sql.selectColor("brown");
            case 4:
                return sql.selectColor("red");
            case 5:
                return sql.selectColor("black");
            default:
                return sql.selectColor("white");
        }
    }
}
